<!DOCTYPE html>
<html lang="en">
<head>
  <title>Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="voting.css" type="text/css" rel="stylesheet" />

<script src="jscript/gen_validatorv4.js" type="text/javascript"></script>
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>
<body>

<div class="jumbotron">
  <h1>ABV-IIITM</h1>      

</div>
<h3><marquee style="color:#22211f;">Speak it out through voting-2015</marquee></h3>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="student.php">Student Election Portal</a>
    </div>
    <div>
      <ul class="nav navbar-nav">
        <li class="active"><a href="student.php">Home</a></li>
        <li><a href="can_view.php">Candidate</a></li>
        <li><a href="question.php">Questions</a></li>
        <li><a href="logout.php">Logout</a></li>
		 <li><a href="change_pass.php">Change Password</a></li>
      </ul>
    </div>
  </div>
</nav>

