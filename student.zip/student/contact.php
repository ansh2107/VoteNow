<?php include "nav.php";?>
<div class="container">

<div id="content">
<?php global $msg; echo $msg;?>
<br/><h3>Welcome, contact page.</h3><br/>
<p>You may find us with below conact:
<ul>
<li>Ansul Sharma: 9479329771</a></li>
<li>Ankit Bansal: 8989478182</li>
<li>Sahil Kori: 0789989898</li>
</ul>
</p>
<p>&nbsp;&nbsp;</p>
</div>
</div>
<?php include "footer.php";?>
