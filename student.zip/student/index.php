<?php include "nav.php";?>
<div class="container">

<div id="content">
<?php global $msg; echo $msg;?>

<br/><h3>Welcome,</h3><br/>
<p>This system allows all registered student to vote for their candidates student in IFM. Remember to keep hidding your information like
student ID card number since the default username in the system is your registration number and password is your course.</p>
<p>In order to make a vote you have to be registered on the student information system.<br/>
    -Candidates may still vote for them selves since they are IFM students<br/>
    -Most recently information will updates in this site to make follow up on election</p>
    <p>&nbsp;&nbsp;</p>
</div>

</div>
<?php include "footer.php";?>
